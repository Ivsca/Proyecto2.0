from django.shortcuts import render, redirect, get_object_or_404
from .models import Cultivo, TipoCultivo, Ganado, TipoParcela,TipoRaza
from django.http import HttpResponse, JsonResponse
from django.core.files.storage import FileSystemStorage
from django.utils.dateparse import parse_date
from django.conf import settings
import os
def home(request):
    return render(request, 'index.html')

# region Logueo
def register_user(request):
    return render(request, 'Logueo/register_user.html')

def login_user(request):
    return render(request, 'Logueo/login_user.html')


# endregion

# region cultivos
def Cultivos(request):
    cultivos = Cultivo.objects.all()
    tipo_Cultivo= TipoCultivo.objects.all()
    return render(request, 'CrudCultivos/Cultivos.html',{
        'cultivos':cultivos,
        'tipo_Cultivo':tipo_Cultivo
    })

def AgregarCultivo(request, CategoriaCultivo, Tipo_Cultivo, Descripcion, cantidad, fecha_cosechado):
    # Obtiene la instancia de TipoCultivo relacionada
    tipo_cultivo_instance = TipoCultivo.objects.get(nombre=Tipo_Cultivo)

    # Crear una nueva instancia de Cultivo con los datos proporcionados
    nuevo_cultivo = Cultivo(
        CategoriaCultivo=CategoriaCultivo,
        Tipo_Cultivo=tipo_cultivo_instance,
        Descripcion=Descripcion,
        cantidad=cantidad,
        fecha_cosechado=fecha_cosechado
    )

    # Guardar la nueva instancia en la base de datos
    nuevo_cultivo.save()

    # Redirigir a la lista de cultivos después de agregar el nuevo registro
    return redirect('/cultivos/list/')

def VerCultivo(request, id_cultivo):
    cultivo = get_object_or_404(Cultivo, id=id_cultivo)
    # Aquí puedes construir un JsonResponse o el HTML necesario para la alerta SweetAlert
    data = {
        'CategoriaCultivo': cultivo.CategoriaCultivo,
        'Tipo_Cultivo': cultivo.Tipo_Cultivo.nombre,
        'Descripcion': cultivo.Descripcion,
        'Cantidad': cultivo.cantidad,
        'Fecha_Cosechado': cultivo.fecha_cosechado,
        # Puedes agregar más datos aquí si es necesario
    }
    return JsonResponse(data)

def actualizar_cultivo(request, id_cultivo):
    return redirect('Cultivos')

def BorrarCultivo(request,id_cultivo):
    cultivo = Cultivo.objects.get(id=id_cultivo)
    cultivo.delete()
    return redirect('/cultivos/list/')
# endregion

# region ganado
def ganado_list(request):
    ganado =  Ganado.objects.all()
    parcelas = TipoParcela.objects.all()
    razas = TipoRaza.objects.all()
    return render(request, 'CrudGanado/ganado.html',{
        'ganado': ganado,
        'parcelas':parcelas,
        'razas':razas
    })


def AgregarVacuno(request):
    fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'ImagenesGanado'))
    if request.method == 'POST':
        # Captura los datos del formulario
        codigo = request.POST.get('codigo')
        imagen_vacuno = request.FILES.get('ImagenVacuno')
        crias = request.POST.get('crias')
        codigo_papa = request.POST.get('CodigoPapa')
        codigo_mama = request.POST.get('CodigoMama')
        raza = request.POST.get('raza')
        edad = request.POST.get('edad')
        proposito = request.POST.get('proposito')
        origen = request.POST.get('origen')
        estado = request.POST.get('estado')
        dia_vacunada = request.POST.get('Dia_vacunada')
        dia_caduca_vacunada = request.POST.get('Dia_caduca_vacunada')
        parcela = request.POST.get('parcela')
        alimentacion = request.POST.get('alimentacion')
        enfermedades = request.POST.get('enfermedades')
        vacunas = request.POST.get('vacunas')

        # Convierte las fechas
        dia_vacunada = parse_date(dia_vacunada)
        dia_caduca_vacunada = parse_date(dia_caduca_vacunada)

        # Maneja el archivo de imagen
        if imagen_vacuno:
            # Guarda el archivo usando FileSystemStorage
            filename = fs.save(imagen_vacuno.name, imagen_vacuno)
            image_url = fs.url(filename)
        else:
            image_url = None

        # Crea una instancia del modelo Ganado
        ganado = Ganado(
            codigo=codigo,
            ImagenVacuno=image_url,
            crias=crias,
            CodigoPapa=codigo_papa,
            CodigoMama=codigo_mama,
            raza_id=raza,
            edad=edad,
            proposito=proposito,
            estado=estado,
            vacunas=vacunas,
            Dia_vacunada=dia_vacunada,
            Dia_caduca_vacunada=dia_caduca_vacunada,
            parcela_id=parcela,
            alimentacion=alimentacion,
            enfermedades=enfermedades,
            origen=origen
        )
        
        # Guarda la instancia en la base de datos
        ganado.save()
        return redirect('/ganado/list/')


def VerGanado(request, id_ganado, codigo, crias, CodigoPapa, CodigoMama, raza, edad, proposito, estado, vacunas, Dia_vacunada, Dia_caduca_vacunada, parcela, alimentacion, enfermedades, origen):
    ganado = get_object_or_404(Ganado, id=id_ganado)

    # Preparar la data a devolver como JSON
    data = {
        'codigo': ganado.codigo,
        'crias': ganado.crias,
        'CodigoPapa': ganado.CodigoPapa,
        'CodigoMama': ganado.CodigoMama,
        'raza': ganado.raza.nombre,  # Asegúrate de que raza tenga el campo 'nombre'
        'edad': ganado.edad,
        'proposito': ganado.proposito,
        'estado': ganado.estado,
        'vacunas': ganado.vacunas,
        'Dia_vacunada': ganado.Dia_vacunada.strftime('%Y-%m-%d'),
        'Dia_caduca_vacunada': ganado.Dia_caduca_vacunada.strftime('%Y-%m-%d'),
        'parcela': ganado.parcela.nombre,  # Asegúrate de que parcela tenga el campo 'nombre'
        'alimentacion': ganado.alimentacion,
        'enfermedades': ganado.enfermedades,
        'origen': ganado.origen,
    }
    return JsonResponse(data)


def ActualizarVacuno(request, id_vacuno):
    # Obtén el vacuno que se quiere actualizar
    vacuno = get_object_or_404(Ganado, id=id_vacuno)
    fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'ImagenesGanado'))

    if request.method == 'POST':
        # Captura los datos del formulario
        codigo = request.POST.get('codigo')
        imagen_vacuno = request.FILES.get('ImagenVacuno')
        crias = request.POST.get('crias')
        codigo_papa = request.POST.get('CodigoPapa')
        codigo_mama = request.POST.get('CodigoMama')
        raza = request.POST.get('raza')
        edad = request.POST.get('edad')
        proposito = request.POST.get('proposito')
        origen = request.POST.get('origen')
        estado = request.POST.get('estado')
        dia_vacunada = request.POST.get('Dia_vacunada')
        dia_caduca_vacunada = request.POST.get('Dia_caduca_vacunada')
        parcela = request.POST.get('parcela')
        alimentacion = request.POST.get('alimentacion')
        enfermedades = request.POST.get('enfermedades')
        vacunas = request.POST.get('vacunas')

        # Convierte las fechas
        dia_vacunada = parse_date(dia_vacunada)
        dia_caduca_vacunada = parse_date(dia_caduca_vacunada)

        # Manejo de la imagen solo si se subió una nueva
        if imagen_vacuno:
            # Borra la imagen antigua si existe una nueva
            if vacuno.ImagenVacuno:
                fs.delete(vacuno.ImagenVacuno)

            # Guarda la nueva imagen usando FileSystemStorage
            filename = fs.save(imagen_vacuno.name, imagen_vacuno)
            image_url = fs.url(filename)
            vacuno.ImagenVacuno = image_url

        # Actualiza los campos del vacuno existente
        vacuno.codigo = codigo
        vacuno.crias = crias
        vacuno.CodigoPapa = codigo_papa
        vacuno.CodigoMama = codigo_mama
        vacuno.raza_id = raza
        vacuno.edad = edad
        vacuno.proposito = proposito
        vacuno.origen = origen
        vacuno.estado = estado
        vacuno.Dia_vacunada = dia_vacunada
        vacuno.Dia_caduca_vacunada = dia_caduca_vacunada
        vacuno.parcela_id = parcela
        vacuno.alimentacion = alimentacion
        vacuno.enfermedades = enfermedades
        vacuno.vacunas = vacunas

        # Guarda los cambios en la base de datos
        vacuno.save()

        # Redirige a la lista de ganado
        return redirect('/ganado/list/')
    
def BorrarVacuno(request,id_vacuno):
    vacuno = Ganado.objects.get(id=id_vacuno)
    vacuno.delete()
    return redirect('/ganado/list/')
# endregion