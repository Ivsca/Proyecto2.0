from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', views.home),
# region Logueo
    path('Logueo/login_user/',views.login_user),
    path('Logueo/Register_user/', views.register_user),
# endregion
# region Cultivos
    path('cultivos/list/', views.Cultivos),
    path('cultivos/agregar/<str:CategoriaCultivo>/<str:Tipo_Cultivo>/<str:Descripcion>/<int:cantidad>/<str:fecha_cosechado>/', views.AgregarCultivo),
    path('cultivos/ver/<int:id_cultivo>/', views.VerCultivo),
    path('cultivos/actualizar/<int:id_cultivo>/<str:CategoriaCultivo>/<str:TipoCultivo>/<str:Descripcion>/<int:cantidad>/<str:fecha_cosechado>/', views.actualizar_cultivo),
    path('cultivos/borrar/<str:id_cultivo>/', views.BorrarCultivo),
# endregion
# region Ganado
    path('ganado/list/',views.ganado_list),
    path('ganado/agregar/', views.AgregarVacuno, name='agregar_vacuno'),
    path('ganado/ver/', views.VerGanado),
    path('ganado/actualizar/<str:id_vacuno>/', views.ActualizarVacuno, name='actualizar_vacuno'),
    path('ganado/borrar/<str:id_vacuno>/', views.BorrarVacuno),
# endregion
]
